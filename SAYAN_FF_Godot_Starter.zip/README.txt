SAYAN FF - GODOT STARTER PROJECT

This is a starter prototype, not a complete Free Fire-scale game.

Included:
- Original SAYAN FF project identity
- 3D training ground scene using primitive placeholder geometry
- Third-person player capsule and camera
- WASD movement, jump, mouse look and raycast shooting
- Simple target dummies with health

Open:
1. Install Godot 4.x.
2. Extract this ZIP.
3. In Godot Project Manager choose Import.
4. Select the project.godot file.
5. Run the project.

Important:
- The included prototype is desktop-input oriented and needs mobile touch controls before phone gameplay.
- It does not yet include BR/CS, online multiplayer, voice chat, login, backend, production art, or Play Store signing.
- Do not publish this starter as the finished game.
- Use original licensed assets and implement secure server-side rewards and accounts.
